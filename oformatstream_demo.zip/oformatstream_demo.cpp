// oformatstream_demo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

void TestFormat();

int main(int argc, char* argv[])
{
	TestFormat();
	return 0;
}
